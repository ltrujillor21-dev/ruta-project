// script.js - Lógica de login simple + generación de tarjetas y filtros
const sampleRoutes = [
  {
    id:1,
    title: 'Ruta 101 - Medellín → Bogotá',
    driver: 'Carlos Pérez',
    vehicle: 'Camión C-45',
    eta: '3 días',
    state: 'enruta',
    img: 'img/ruta1.svg',
    description: 'Carga: 12 pallets de café. Prioridad media. Ruta por autopista.'
  },
  {
    id:2,
    title: 'Ruta 203 - Cali → Medellín',
    driver: 'Ana Gómez',
    vehicle: 'Camión T-12',
    eta: '1 día',
    state: 'pendiente',
    img: 'img/ruta2.svg',
    description: 'Carga: repuestos automotrices. Requiere revisión previa.'
  },
  {
    id:3,
    title: 'Ruta 330 - Barranquilla → Cartagena',
    driver: 'Luis Martínez',
    vehicle: 'Camión L-88',
    eta: '6 horas',
    state: 'entregado',
    img: 'img/ruta3.svg',
    description: 'Entrega en puerto completada. Firma digital almacenada.'
  }
];

function saveMockData(){ localStorage.setItem('routes', JSON.stringify(sampleRoutes)); }
function getRoutes(){ return JSON.parse(localStorage.getItem('routes') || '[]'); }

document.addEventListener('DOMContentLoaded', ()=> {
  // RUTAS: si estamos en index (login) o dashboard
  if(document.getElementById('loginForm')){
    const form = document.getElementById('loginForm');
    form.addEventListener('submit', (e)=>{
      e.preventDefault();
      const u = document.getElementById('user').value.trim();
      const p = document.getElementById('pass').value.trim();
      if(u === 'admin' && p === '1234'){
        sessionStorage.setItem('logged','admin');
        // preparar datos de ejemplo
        saveMockData();
        window.location.href = 'dashboard.html';
      } else {
        alert('Usuario o contraseña incorrectos. Prueba admin / 1234');
      }
    });
    return;
  }

  // Dashboard logic
  if(!sessionStorage.getItem('logged')){
    // No autorizado -> volver a login
    window.location.href = 'index.html';
    return;
  }

  const cardsEl = document.getElementById('cards');
  const modal = document.getElementById('modal');
  const modalBody = document.getElementById('modalBody');
  const closeModal = document.getElementById('closeModal');
  const logoutBtn = document.getElementById('logoutBtn');
  const addRouteBtn = document.getElementById('addRouteBtn');
  const filterState = document.getElementById('filterState');
  const searchInput = document.getElementById('searchInput');

  // Initialize storage if empty
  if(!localStorage.getItem('routes')) saveMockData();

  function renderCards(routes){
    cardsEl.innerHTML = '';
    routes.forEach(r => {
      const div = document.createElement('article');
      div.className = 'route-card card';
      div.innerHTML = `
        <img class="route-img" src="${r.img}" alt="${r.title}">
        <div class="route-body">
          <div class="hstack">
            <strong>${r.title}</strong>
            <span class="badge ${r.state}">${r.state}</span>
          </div>
          <div class="meta">Conductor: ${r.driver} · Vehículo: ${r.vehicle}</div>
          <div class="meta">ETA: ${r.eta}</div>
          <div class="btn-row">
            <button class="btn view" data-id="${r.id}">Ver</button>
            <button class="btn edit" data-id="${r.id}">Editar</button>
          </div>
        </div>
      `;
      cardsEl.appendChild(div);
    });

    // attach handlers
    document.querySelectorAll('.btn.view').forEach(b=>{
      b.addEventListener('click', ()=> {
        const id = +b.dataset.id;
        const route = getRoutes().find(x=>x.id===id);
        if(route){
          modalBody.innerHTML = `
            <h2>${route.title}</h2>
            <img style="width:100%;max-height:260px;object-fit:cover;border-radius:10px" src="${route.img}" alt="">
            <p style="margin-top:10px">${route.description}</p>
            <ul style="margin-top:8px">
              <li><strong>Conductor:</strong> ${route.driver}</li>
              <li><strong>Vehículo:</strong> ${route.vehicle}</li>
              <li><strong>ETA:</strong> ${route.eta}</li>
              <li><strong>Estado:</strong> ${route.state}</li>
            </ul>
          `;
          modal.classList.remove('hidden');
        }
      });
    });

    document.querySelectorAll('.btn.edit').forEach(b=>{
      b.addEventListener('click', ()=> {
        alert('Aquí podrías abrir un formulario para editar la ruta (demostración).');
      });
    });
  }

  // Initial render
  renderCards(getRoutes());

  // Filters
  filterState.addEventListener('change', ()=> applyFilters());
  searchInput.addEventListener('input', ()=> applyFilters());

  function applyFilters(){
    const state = filterState.value;
    const q = searchInput.value.toLowerCase().trim();
    let routes = getRoutes();
    if(state !== 'all') routes = routes.filter(r=> r.state === state);
    if(q) routes = routes.filter(r => (
      r.driver.toLowerCase().includes(q) ||
      r.vehicle.toLowerCase().includes(q) ||
      r.title.toLowerCase().includes(q)
    ));
    renderCards(routes);
  }

  // modal close
  closeModal.addEventListener('click', ()=> modal.classList.add('hidden'));
  modal.addEventListener('click', (e)=> { if(e.target === modal) modal.classList.add('hidden') });

  // logout
  logoutBtn.addEventListener('click', ()=>{
    sessionStorage.removeItem('logged');
    window.location.href = 'index.html';
  });

  addRouteBtn.addEventListener('click', ()=>{
    alert('Funcionalidad de agregar ruta: en la versión de demostración puedes editar el código para añadirla.');
  });
});
